pref("extensions.BrowserServer.boolpref", false);
pref("extensions.BrowserServer.intpref", 0);
pref("extensions.BrowserServer.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.browserServer.description", "chrome://BrowserServer/locale/overlay.properties");
